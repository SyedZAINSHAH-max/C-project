using System.Xml.Linq;

namespace FishingFleetQuota
{

    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAddBoat_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Record Added Successfully");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Record removed Successfully");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Record Added Successfully");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Record removed Successfully");
        }
    }
}