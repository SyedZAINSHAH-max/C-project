﻿namespace FishingFleetQuota
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            label1 = new Label();
            tableLayoutPanel2 = new TableLayoutPanel();
            tableLayoutPanel3 = new TableLayoutPanel();
            groupBox1 = new GroupBox();
            button2 = new Button();
            btnAddBoat = new Button();
            checkedListBox1 = new CheckedListBox();
            label3 = new Label();
            numMaxLoad = new NumericUpDown();
            label2 = new Label();
            txtLicenseNumber = new TextBox();
            txtBoatName = new TextBox();
            groupBox3 = new GroupBox();
            button1 = new Button();
            button3 = new Button();
            comboBox2 = new ComboBox();
            dataGridView1 = new DataGridView();
            label4 = new Label();
            comboBox1 = new ComboBox();
            groupBox2 = new GroupBox();
            listBox1 = new ListBox();
            groupBox4 = new GroupBox();
            dataGridView2 = new DataGridView();
            tableLayoutPanel1.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numMaxLoad).BeginInit();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox2.SuspendLayout();
            groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Controls.Add(label1, 0, 0);
            tableLayoutPanel1.Dock = DockStyle.Top;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(1819, 49);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Dock = DockStyle.Fill;
            label1.Font = new Font("Times New Roman", 16F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(3, 0);
            label1.Name = "label1";
            label1.Size = new Size(1813, 49);
            label1.TabIndex = 0;
            label1.Text = "Welcome to Fishing Fleet Quota";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 3;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42.1660271F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.4716873F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 39.3622856F));
            tableLayoutPanel2.Controls.Add(tableLayoutPanel3, 0, 0);
            tableLayoutPanel2.Controls.Add(groupBox2, 1, 0);
            tableLayoutPanel2.Controls.Add(groupBox4, 2, 0);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(0, 49);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel2.Size = new Size(1819, 835);
            tableLayoutPanel2.TabIndex = 1;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 1;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40.26258F));
            tableLayoutPanel3.Controls.Add(groupBox1, 0, 0);
            tableLayoutPanel3.Controls.Add(groupBox3, 0, 1);
            tableLayoutPanel3.Dock = DockStyle.Fill;
            tableLayoutPanel3.Location = new Point(3, 3);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 2;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 48.29932F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 51.70068F));
            tableLayoutPanel3.Size = new Size(761, 829);
            tableLayoutPanel3.TabIndex = 0;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(btnAddBoat);
            groupBox1.Controls.Add(checkedListBox1);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(numMaxLoad);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(txtLicenseNumber);
            groupBox1.Controls.Add(txtBoatName);
            groupBox1.Dock = DockStyle.Fill;
            groupBox1.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(3, 3);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(755, 394);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Boat Details";
            // 
            // button2
            // 
            button2.BackColor = Color.Red;
            button2.Dock = DockStyle.Right;
            button2.Location = new Point(488, 318);
            button2.Name = "button2";
            button2.Size = new Size(264, 73);
            button2.TabIndex = 9;
            button2.Text = "Remove Boat";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // btnAddBoat
            // 
            btnAddBoat.BackColor = Color.LimeGreen;
            btnAddBoat.Dock = DockStyle.Left;
            btnAddBoat.Location = new Point(3, 318);
            btnAddBoat.Name = "btnAddBoat";
            btnAddBoat.Size = new Size(264, 73);
            btnAddBoat.TabIndex = 8;
            btnAddBoat.Text = "Add Boat";
            btnAddBoat.UseVisualStyleBackColor = false;
            btnAddBoat.Click += btnAddBoat_Click;
            // 
            // checkedListBox1
            // 
            checkedListBox1.BorderStyle = BorderStyle.FixedSingle;
            checkedListBox1.Dock = DockStyle.Top;
            checkedListBox1.FormattingEnabled = true;
            checkedListBox1.Items.AddRange(new object[] { "Cod", "Salmon", "Tuna", "Sardine" });
            checkedListBox1.Location = new Point(3, 188);
            checkedListBox1.Name = "checkedListBox1";
            checkedListBox1.Size = new Size(749, 130);
            checkedListBox1.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = DockStyle.Top;
            label3.Location = new Point(3, 162);
            label3.Name = "label3";
            label3.Size = new Size(248, 26);
            label3.TabIndex = 6;
            label3.Text = "Select the Fish Species ";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // numMaxLoad
            // 
            numMaxLoad.BorderStyle = BorderStyle.FixedSingle;
            numMaxLoad.Dock = DockStyle.Top;
            numMaxLoad.Location = new Point(3, 127);
            numMaxLoad.Name = "numMaxLoad";
            numMaxLoad.Size = new Size(749, 35);
            numMaxLoad.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = DockStyle.Top;
            label2.Location = new Point(3, 101);
            label2.Name = "label2";
            label2.Size = new Size(232, 26);
            label2.TabIndex = 3;
            label2.Text = "Select Max Load (kg)";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // txtLicenseNumber
            // 
            txtLicenseNumber.BorderStyle = BorderStyle.FixedSingle;
            txtLicenseNumber.Dock = DockStyle.Top;
            txtLicenseNumber.Location = new Point(3, 66);
            txtLicenseNumber.Name = "txtLicenseNumber";
            txtLicenseNumber.PlaceholderText = "Enter the license number of the boat";
            txtLicenseNumber.Size = new Size(749, 35);
            txtLicenseNumber.TabIndex = 1;
            txtLicenseNumber.TextChanged += textBox2_TextChanged;
            // 
            // txtBoatName
            // 
            txtBoatName.BorderStyle = BorderStyle.FixedSingle;
            txtBoatName.Dock = DockStyle.Top;
            txtBoatName.Location = new Point(3, 31);
            txtBoatName.Name = "txtBoatName";
            txtBoatName.PlaceholderText = "Enter the name of the boat";
            txtBoatName.Size = new Size(749, 35);
            txtBoatName.TabIndex = 0;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(button1);
            groupBox3.Controls.Add(button3);
            groupBox3.Controls.Add(comboBox2);
            groupBox3.Controls.Add(dataGridView1);
            groupBox3.Controls.Add(label4);
            groupBox3.Controls.Add(comboBox1);
            groupBox3.Dock = DockStyle.Fill;
            groupBox3.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox3.Location = new Point(3, 403);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(755, 423);
            groupBox3.TabIndex = 1;
            groupBox3.TabStop = false;
            groupBox3.Text = "Catch Report";
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.Dock = DockStyle.Right;
            button1.Location = new Point(488, 375);
            button1.Name = "button1";
            button1.Size = new Size(264, 45);
            button1.TabIndex = 11;
            button1.Text = "Remove Boat";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.LimeGreen;
            button3.Dock = DockStyle.Left;
            button3.Location = new Point(3, 375);
            button3.Name = "button3";
            button3.Size = new Size(264, 45);
            button3.TabIndex = 10;
            button3.Text = "Add Boat";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // comboBox2
            // 
            comboBox2.Dock = DockStyle.Top;
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(3, 341);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(749, 34);
            comboBox2.TabIndex = 3;
            comboBox2.Text = "select whether to display weights in kg or tonnes";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Dock = DockStyle.Top;
            dataGridView1.Location = new Point(3, 91);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.Size = new Size(749, 250);
            dataGridView1.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Dock = DockStyle.Top;
            label4.Location = new Point(3, 65);
            label4.Name = "label4";
            label4.Size = new Size(184, 26);
            label4.TabIndex = 1;
            label4.Text = "Fish Caught (kg)";
            // 
            // comboBox1
            // 
            comboBox1.Dock = DockStyle.Top;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(3, 31);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(749, 34);
            comboBox1.TabIndex = 0;
            comboBox1.Text = "Select a boat from the fleet";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(listBox1);
            groupBox2.Dock = DockStyle.Top;
            groupBox2.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox2.Location = new Point(770, 3);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(330, 450);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "The List of Boats in the Fleet";
            // 
            // listBox1
            // 
            listBox1.Dock = DockStyle.Fill;
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 26;
            listBox1.Location = new Point(3, 31);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(324, 416);
            listBox1.TabIndex = 0;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(dataGridView2);
            groupBox4.Dock = DockStyle.Fill;
            groupBox4.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox4.Location = new Point(1106, 3);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(710, 829);
            groupBox4.TabIndex = 2;
            groupBox4.TabStop = false;
            groupBox4.Text = "Quota Report";
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Dock = DockStyle.Fill;
            dataGridView2.Location = new Point(3, 31);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 62;
            dataGridView2.RowTemplate.Height = 33;
            dataGridView2.Size = new Size(704, 795);
            dataGridView2.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1819, 884);
            Controls.Add(tableLayoutPanel2);
            Controls.Add(tableLayoutPanel1);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Fishing Fleet Quota";
            WindowState = FormWindowState.Maximized;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel3.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numMaxLoad).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Label label1;
        private TableLayoutPanel tableLayoutPanel2;
        private TableLayoutPanel tableLayoutPanel3;
        private GroupBox groupBox1;
        private TextBox txtLicenseNumber;
        private TextBox txtBoatName;
        private Label label2;
        private NumericUpDown numMaxLoad;
        private CheckedListBox checkedListBox1;
        private Label label3;
        private Button button2;
        private Button btnAddBoat;
        private GroupBox groupBox2;
        private ListBox listBox1;
        private GroupBox groupBox3;
        private Button button1;
        private Button button3;
        private ComboBox comboBox2;
        private DataGridView dataGridView1;
        private Label label4;
        private ComboBox comboBox1;
        private GroupBox groupBox4;
        private DataGridView dataGridView2;
    }
}